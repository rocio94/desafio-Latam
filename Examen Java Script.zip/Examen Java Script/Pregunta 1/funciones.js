$(document).ready(function(){
var suma = 0;
do
var ingreso = prompt("ingresa un número");
while (ingreso != "fin");
console.log(suma)
});